// src/components/Main.js
import React from "react";

const Banner = () => {
  return (
    <main>
      <div className="hero">
        <h2>Build your Dream home</h2>
        <p>
          Cras ac sapien eget ante faucibus tempus et eu tortor. Integer iaculis
          ultrices velit nec tempor. Pellentesque aliquet sit amet mi auctor
          nec.
        </p>
        <button>Get Started</button>
      </div>
    </main>
  );
};

export default Banner;
