import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

function Footer() {
  return (
    <div>
      <footer className="bg-dark text-white pt-4 footer">
        <Container>
          <Row>
            <Col md={3}>
              <h5>Skyline Builderz</h5>
              <p>
                Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit
                aut fugit consequuntur magni dolores eos qui ratione.
              </p>
              <div>
                <a href="facebook" className="text-white me-2">
                  Facebook
                </a>
                <a href="instagram" className="text-white me-2">
                  Instagram
                </a>
                <a href="linkedin" className="text-white">
                  LinkedIn
                </a>
              </div>
            </Col>
            <Col md={2}>
              <h5>Contact</h5>
              <p>(629) 555-0129</p>
              <p>info@example.com</p>
              <p>6391 Elgin St, Celina, 10299</p>
            </Col>

            <Col md={2}>
              <h5>Page</h5>
              <ul className="list-unstyled">
                <li>
                  <a href="about" className="text-white">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="contact" className="text-white">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="blog" className="text-white">
                    Blogs
                  </a>
                </li>
                <li>
                  <a href="service" className="text-white">
                    Service
                  </a>
                </li>
              </ul>
            </Col>

            <Col md={2}>
              <h5>Quick Links</h5>
              <ul className="list-unstyled">
                <li>
                  <a href="terms" className="text-white">
                    Terms and Conditions
                  </a>
                </li>
                <li>
                  <a href="privacy" className="text-white">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="fqs" className="text-white">
                    FAQs
                  </a>
                </li>
                <li>
                  <a href="support" className="text-white">
                    Support Center
                  </a>
                </li>
              </ul>
            </Col>
            <Col md={3}>
              <form className="d-flex justify-content-center">
                <input
                  type="text"
                  className="form-control me-2"
                  placeholder="Get product updates"
                />
                <button className="btn btn-warning" type="submit">
                  Subscribe
                </button>
              </form>
            </Col>
          </Row>
          <Row>
            <hr className="footer-hr" />
          </Row>
          <Row>
            <div className="text-center py-3">
              © 2024 Copyright. All rights reserved.
            </div>
          </Row>
        </Container>
      </footer>
    </div>
  );
}

export default Footer;
